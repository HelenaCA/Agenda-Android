package me.parzibyte.crudsqlite.adaptadores;

import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.ArrayList;

import me.parzibyte.crudsqlite.R;
import me.parzibyte.crudsqlite.modelos.Contacto;

public class AdaptadorContacto extends RecyclerView.Adapter<AdaptadorContacto.ViewHolderContactos> {

    ArrayList<Contacto> listaContactos;

    public AdaptadorContacto(ArrayList<Contacto> listaContactos) {
        this.listaContactos = listaContactos;
    }

    public void setListaContactos(ArrayList<Contacto> listaDeContactos) {
        this.listaContactos = listaDeContactos;
    }

    @Override
    public ViewHolderContactos onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fila_contacto,null,false);
        return new ViewHolderContactos(view);
    }

    @Override
    public void onBindViewHolder( ViewHolderContactos holder, int position) {
        holder.nombreVista.setText(listaContactos.get(position).getNombre());
       try{
           holder.telefonoVista.setText(listaContactos.get(position).getPrimerNumero());
       }catch(Exception e){
           holder.telefonoVista.setText("El contacto no tiene ningún teléfono asociado");
       }

        String image_uri = listaContactos.get(position).getFoto();

        if (listaContactos.get(position).getFoto().equals("girl")) {
            holder.imagenVista.setImageResource(R.mipmap.girl);
        }else if(listaContactos.get(position).getFoto().equals("boy")){
            holder.imagenVista.setImageResource(R.mipmap.boy);
        }else if(listaContactos.get(position).getFoto().equals("dog")){
            holder.imagenVista.setImageResource(R.mipmap.dog);
        }else if(!image_uri.isEmpty()){
            holder.imagenVista.setImageURI(Uri.parse(image_uri));
        }else{
            holder.imagenVista.setImageResource(R.mipmap.zima);
        }
    }

    @Override
    public int getItemCount() {
        return listaContactos.size();
    }

    public class ViewHolderContactos extends RecyclerView.ViewHolder {
        TextView nombreVista;
        TextView telefonoVista;
        ImageView imagenVista;
        public ViewHolderContactos(View itemView) {
            super(itemView);
            nombreVista=(TextView)itemView.findViewById(R.id.txtNombreVista);
            telefonoVista=(TextView)itemView.findViewById(R.id.txtTelefonoVista);
            imagenVista=(ImageView)itemView.findViewById(R.id.imgVista);
        }
    }
}
