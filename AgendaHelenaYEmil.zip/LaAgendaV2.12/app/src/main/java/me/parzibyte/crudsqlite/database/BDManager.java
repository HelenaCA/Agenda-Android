package me.parzibyte.crudsqlite.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

import me.parzibyte.crudsqlite.modelos.Contacto;
import me.parzibyte.crudsqlite.modelos.Telefono;

public class BDManager extends SQLiteOpenHelper {
    private static final String NOMBRE_BASE_DE_DATOS = "AgendaEH";
    private static final int VERSION_BASE_DE_DATOS = 1;
    private static final String NOMBRE_TABLA_CONTACTOS = "TContacto";
    private static final String NOMBRE_TABLA_TELEFONOS = "TTelefono";
    private static final String NOMBRE_TABLA_EMAILS = "TEmail";
    private Contacto c;

    public BDManager(Context context) {
        super(context, NOMBRE_BASE_DE_DATOS, null, VERSION_BASE_DE_DATOS);
    }

    //Métodos de SQLiteOpenHelper
    @Override
    public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS TContacto(" +
                "nContactoId INTEGER NOT NULL PRIMARY KEY UNIQUE ," +
                "cNombre VARCHAR(100) NOT NULL ," +
                "cFoto TEXT)");

        db.execSQL("CREATE TABLE TTelefono ( " +
                "cTelefono TEXT NOT NULL PRIMARY KEY , " +
                "cTipo TEXT NOT NULL , " +
                "nContactoId INTEGER NOT NULL , " +
                "FOREIGN KEY(nContactoId) REFERENCES TContacto(nContactoId) ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE TEmail ( " +
                "cEmail TEXT NOT NULL PRIMARY KEY , " +
                "nContactoId INTEGER NOT NULL , " +
                "FOREIGN KEY(nContactoId) REFERENCES TContacto(nContactoId) ON DELETE CASCADE)");

        //default test values
        db.execSQL("INSERT INTO TContacto (nContactoId, cNombre,cFoto) VALUES (1, 'Helena','girl')");
        db.execSQL("INSERT INTO TContacto (nContactoId, cNombre,cFoto) VALUES (2, 'Emil','boy')");
        db.execSQL("INSERT INTO TContacto (nContactoId, cNombre,cFoto) VALUES (3, 'Dobby','dog')");
        db.execSQL("INSERT INTO TContacto (nContactoId, cNombre,cFoto) VALUES (4, 'Gala','dog')");

        //default test value
        db.execSQL("INSERT INTO TTelefono (cTelefono,cTipo,nContactoId) VALUES ('606063035','Móvil', 1)");
        db.execSQL("INSERT INTO TTelefono (cTelefono,cTipo,nContactoId) VALUES ('91111111','Fijo', 1)");
        db.execSQL("INSERT INTO TTelefono (cTelefono,cTipo,nContactoId) VALUES ('600447346','Móvil', 1)");
        db.execSQL("INSERT INTO TTelefono (cTelefono,cTipo,nContactoId) VALUES ('666666666','Móvil', 2)");
        db.execSQL("INSERT INTO TTelefono (cTelefono,cTipo,nContactoId) VALUES ('912222222','Fijo', 2)");
        db.execSQL("INSERT INTO TTelefono (cTelefono,cTipo,nContactoId) VALUES ('84848484','Móvil', 3)");
        db.execSQL("INSERT INTO TTelefono (cTelefono,cTipo,nContactoId) VALUES ('85858585','Móvil', 4)");

        //default test value
        db.execSQL("INSERT INTO TEmail (cEmail, nContactoId) VALUES ('helenacanaandres@gmail.com', 1)");
        db.execSQL("INSERT INTO TEmail (cEmail, nContactoId) VALUES ('helenitaconhache@gmail.com', 1)");
        db.execSQL("INSERT INTO TEmail (cEmail, nContactoId) VALUES ('hele92_mad_girl@gmail.com', 1)");
        db.execSQL("INSERT INTO TEmail (cEmail, nContactoId) VALUES ('fulljockernoseque@gmail.com', 2)");
        db.execSQL("INSERT INTO TEmail (cEmail, nContactoId) VALUES ('emiltimoteibeldean97@gmail.com', 2)");
        db.execSQL("INSERT INTO TEmail (cEmail, nContactoId) VALUES ('wololowoof@gmail.com', 3)");
        db.execSQL("INSERT INTO TEmail (cEmail, nContactoId) VALUES ('dobbyesunperrolibre@gmail.com', 3)");
        db.execSQL("INSERT INTO TEmail (cEmail, nContactoId) VALUES ('oasisespeorqueblur@gmail.com', 4)");
        db.execSQL("INSERT INTO TEmail (cEmail, nContactoId) VALUES ('galita@gmail.com', 4)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //db.execSQL("DROP TABLE IF EXISTS TContacto");
        //db.execSQL("DROP TABLE IF EXISTS TTelefono");
        //db.execSQL("DROP TABLE IF EXISTS TEmail");
        onCreate(db);
    }

    /**
     * @param contacto
     * @return
     */
    public boolean crearContacto(Contacto contacto) {
        boolean result = false;
        int nContactoId;
        SQLiteDatabase db = getWritableDatabase();
        SQLiteDatabase dbr = getReadableDatabase();
        try {
            db.execSQL("INSERT INTO TContacto(nContactoId, cNombre,cFoto) " +
                    "VALUES ('"+(getMaxId()+1)+ "','" + contacto.getNombre() + "','" + contacto.getFoto() + "')");

            Cursor cursor = dbr.rawQuery("SELECT max(nContactoId) FROM TContacto", null);
            nContactoId = cursor.getInt(0);
            contacto.setId(nContactoId);
            cursor.close();
            result = true;
        } catch (Exception e) {
        }
        db.close();
        dbr.close();
        return result;
    }


    public ArrayList<Contacto> obtenerContacto() {
        c = null;
        ArrayList<Contacto> alc = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        for (int id = 1; id <= getMaxId(); id++) {
            ArrayList<Telefono> telefonos = new ArrayList<>();
            ArrayList<String> emails = new ArrayList<>();

            try {

                Cursor cursor = db.rawQuery("SELECT cTelefono, cTipo FROM TTelefono WHERE nContactoId=" + id, null);

                while (cursor.moveToNext()) {
                    Telefono t = new Telefono(cursor.getString(0), cursor.getString(1));
                    telefonos.add(t);
                }

                cursor = db.rawQuery("SELECT cEmail FROM TEmail WHERE nContactoId=" + id, null);

                while (cursor.moveToNext()) {
                    emails.add(cursor.getString(0));
                }

                cursor = db.rawQuery("SELECT cNombre, cFoto FROM TContacto WHERE nContactoId=" + id, null);

                while (cursor.moveToNext()) {
                    String nombre = cursor.getString(0);
                    String foto = cursor.getString(1);
                    c = new Contacto(nombre, telefonos, emails, foto);
                }
                alc.add(c);
            } catch (Exception e) {

            }

        }
        return alc;
    }

    public int getMaxId() {
        SQLiteDatabase db = getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT nContactoId FROM TContacto", null);
            cursor.moveToLast();
            return cursor.getInt(0);
        } catch (Exception e) {
            return 0;
        }
    }


    public Cursor cargarContactosCursor(){
        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery("SELECT nContactoId, cNombre, cFoto " +
                        "FROM TContacto"
                , null);
    }

    public Cursor getTelefono(int id){
        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery("SELECT cTelefono, cTipo, nContactoId " +
                "FROM TTelefono " +
                "WHERE nContactoId = " + id, null);
    }


    public Cursor getEmail(int id){
        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery("SELECT cEmail " +
                "FROM TEmail " +
                "WHERE nContactoId = " + id, null);
    }

    public void actualizarNombreYFoto(String nombre, String foto, int id){
        SQLiteDatabase db =getWritableDatabase();

        try{

            db.execSQL("UPDATE TContacto SET " +
                    "cNombre = '" + nombre + "'"+" , " +
                    "cFoto = '"+ foto +"'"+
                    " WHERE nContactoId = " +id);

        }catch(Exception e){

        }
    }

    public void insertarTelefono (Telefono t){
        SQLiteDatabase db = getWritableDatabase();
        SQLiteDatabase db2= getReadableDatabase();

        int nContactoId=0;

        Cursor cursor = db2.rawQuery("Select max(nContactoId) from TContacto",null);
        if (cursor != null) {
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                nContactoId = cursor.getInt(0)+1;
                cursor.moveToNext();
            }
            cursor.close();
        }

        db.execSQL("INSERT INTO TTelefono(cTelefono,cTipo, nContactoId) " +
                "VALUES ('" + t.getNumero() + "','" + t.getTipo() + "','" + nContactoId + "')");

        cursor.close();
    }

    public void insertarTelefonoId (Telefono t){
        SQLiteDatabase db = getWritableDatabase();

        db.execSQL("INSERT INTO TTelefono(cTelefono,cTipo, nContactoId) " +
                "VALUES ('" + t.getNumero() + "','" + t.getTipo() + "','" + t.getContactoId() + "')");

    }

    public int eliminarContacto(Contacto c) {
        SQLiteDatabase baseDeDatos = getWritableDatabase();
        String[] argumentos = {String.valueOf(c.getId())};

        baseDeDatos.delete(NOMBRE_TABLA_TELEFONOS, "nContactoId = ?", argumentos);
        baseDeDatos.delete(NOMBRE_TABLA_EMAILS, "nContactoId = ?", argumentos);
        return baseDeDatos.delete(NOMBRE_TABLA_CONTACTOS, "nContactoId = ?", argumentos);
    }

    public void insertarEmail (String e){
        SQLiteDatabase db = getWritableDatabase();
        SQLiteDatabase db2= getReadableDatabase();

        int nContactoId=0;

        Cursor cursor = db2.rawQuery("Select max(nContactoId) from TContacto",null);
        if (cursor != null) {
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                nContactoId = cursor.getInt(0)+1;
                cursor.moveToNext();
            }
            cursor.close();
        }

        db.execSQL("INSERT INTO TEmail(cEmail, nContactoId) " +
                "VALUES ('" + e + "','" + nContactoId + "')");

        cursor.close();
    }


    public void insertarEmailId (int id, String e){
        SQLiteDatabase db = getWritableDatabase();


        db.execSQL("INSERT INTO TEmail(cEmail, nContactoId) " +
                "VALUES ('" + e + "','" + id + "')");

    }

    public void borrarTelefono(String numero){
        SQLiteDatabase db = getWritableDatabase();
        try {

            db.execSQL("DELETE FROM TTelefono " +
                    "WHERE cTelefono = " + numero);

        } catch (Exception e) {

        }
    }

    public void borrarEmail(String em){
        SQLiteDatabase db = getWritableDatabase();
        try {

            db.execSQL("DELETE FROM TEmail WHERE cEmail = '"+ em+"'");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
