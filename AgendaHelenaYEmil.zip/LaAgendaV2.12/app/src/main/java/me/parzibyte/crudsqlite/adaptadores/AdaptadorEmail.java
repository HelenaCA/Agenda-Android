package me.parzibyte.crudsqlite.adaptadores;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import me.parzibyte.crudsqlite.R;


public class AdaptadorEmail extends RecyclerView.Adapter<AdaptadorEmail.ViewHolderEmails> {

    ArrayList<String> listaEmail;

    public AdaptadorEmail(ArrayList<String> listaEmail) {
        this.listaEmail = listaEmail;
    }

    public void setEmailA(ArrayList<String> listaDeEmail) {
        this.listaEmail = listaDeEmail;
    }



    @Override
    public AdaptadorEmail.ViewHolderEmails onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.email_view_item,null,false);
        return new ViewHolderEmails(view);
    }

    @Override
    public void onBindViewHolder(AdaptadorEmail.ViewHolderEmails holder, int position) {
        holder.emailVista.setText(listaEmail.get(position));
    }

    @Override
    public int getItemCount() {
        return listaEmail.size();
    }

    public class ViewHolderEmails extends RecyclerView.ViewHolder {
        TextView emailVista;
        public ViewHolderEmails(View itemView) {
            super(itemView);
            emailVista=(TextView)itemView.findViewById(R.id.txtEmailitem);
        }


    }
}
