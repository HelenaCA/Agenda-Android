package me.parzibyte.crudsqlite.modelos;

import android.os.Parcel;
import android.os.Parcelable;

public class Telefono implements Parcelable {
    private String numero;
    private String tipo;
    private int contactoId;

    public Telefono(String numero, String tipo){

        this.tipo=tipo;
        this.numero = numero;
    }

    public Telefono(String numero, String tipo, int contactoId){

        this.tipo=tipo;
        this.numero = numero;
        this.contactoId = contactoId;
    }

    protected Telefono(Parcel in) {
        numero = in.readString();
        tipo = in.readString();
        contactoId = in.readInt();
    }

    public static final Creator<Telefono> CREATOR = new Creator<Telefono>() {
        @Override
        public Telefono createFromParcel(Parcel in) {
            return new Telefono(in);
        }

        @Override
        public Telefono[] newArray(int size) {
            return new Telefono[size];
        }
    };

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getContactoId() {
        return contactoId;
    }

    public void setContactoId(int contactoId) {
        this.contactoId = contactoId;
    }


    @Override
    public String toString() {
        return "Telefono{" +
                "numero='" + numero +
                ", tipo='" + tipo +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(numero);
        dest.writeString(tipo);
        dest.writeInt(contactoId);
    }
}
