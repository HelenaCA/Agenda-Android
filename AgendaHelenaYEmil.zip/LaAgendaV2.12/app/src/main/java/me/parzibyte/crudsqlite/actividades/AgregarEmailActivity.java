package me.parzibyte.crudsqlite.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import me.parzibyte.crudsqlite.R;
import me.parzibyte.crudsqlite.database.BDManager;

public class AgregarEmailActivity  extends AppCompatActivity {

    private Button btnCancelar;
    private Button btnAddEmail;
    private EditText etEmail;
    private Intent resultIntent;
    private String email;
    private BDManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.introducir_email);
        manager = new BDManager(this);

        btnCancelar=findViewById(R.id.btnCancelar2);
        btnAddEmail=findViewById(R.id.btnAddEmail);
        etEmail=findViewById(R.id.etEmail);

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnAddEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                crearEmail();
            }
        });
    }

    public void crearEmail(){

        if(!checkEmpty(etEmail)) {
            resultIntent = new Intent();
            email = etEmail.getText().toString();
            resultIntent.putExtra("email", email);
            setResult(RESULT_OK, resultIntent);

            etEmail.setText("");
            finish();
        }
    }

    public boolean checkEmpty(EditText input){
        if(TextUtils.isEmpty(input.getText().toString())){
            input.setError("Este campo no puede estar vacío");
            input.requestFocus();
            return true;
        }
        return false;
    }
}
