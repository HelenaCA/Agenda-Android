package me.parzibyte.crudsqlite.modelos;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Contacto {

    private String nombre;
    private ArrayList<Telefono> alTelefono;
    private ArrayList<String> alEmail;
    private String foto;
    private int id;

    public Contacto(String nombre, ArrayList<Telefono> alTelefono, ArrayList<String> alEmail, String foto, int id){
        this.alTelefono = alTelefono;
        this.alEmail = alEmail;
        this.nombre = nombre;
        this.foto = foto;
        this.id=id;
    }

    public Contacto(String nombre, ArrayList<Telefono> alTelefono, ArrayList<String> alEmail, String foto){
        this.alTelefono = alTelefono;
        this.alEmail = alEmail;
        this.nombre = nombre;
        this.foto = foto;
    }

    public Contacto(){

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {this.id=id;}

    public ArrayList<Telefono> getAlTelefono() {
        return alTelefono;
    }

    public void setAlTelefono(Telefono telefono) {
        alTelefono.add(telefono);
    }

    public void setAlTelefono(ArrayList<Telefono> AlTelefonos) {
        this.alTelefono=AlTelefonos;
    }

    public ArrayList<String> getAlEmail() {
        return alEmail;
    }

    public void setAlEmail(String email) {
        this.alEmail.add(email);
    }

    public void setAlEmail(ArrayList<String> AlEmails) {
        this.alEmail=AlEmails;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getPrimerNumero() {
        return alTelefono.get(0).getNumero();
    }

    @Override
    public String toString() {
        return "Contacto{" +
                "nombre='" + nombre + '\'' +
                ", alTelefono=" + alTelefono +
                ", alEmail=" + alEmail +
                ", foto='" + foto + '\'' +
                ", id=" + id +
                '}';
    }
}
