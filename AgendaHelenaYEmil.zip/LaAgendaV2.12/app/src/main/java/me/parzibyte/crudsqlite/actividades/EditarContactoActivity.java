package me.parzibyte.crudsqlite.actividades;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

import me.parzibyte.crudsqlite.R;
import me.parzibyte.crudsqlite.adaptadores.AdaptadorEmail;
import me.parzibyte.crudsqlite.adaptadores.AdaptadorTelefono;
import me.parzibyte.crudsqlite.adaptadores.RecyclerTouchListener;
import me.parzibyte.crudsqlite.database.BDManager;
import me.parzibyte.crudsqlite.modelos.Contacto;
import me.parzibyte.crudsqlite.modelos.Telefono;

public class EditarContactoActivity extends AppCompatActivity {

    final static int REQUEST_CODE = 1;

    private FloatingActionButton fab1;
    private FloatingActionButton fab2;
    private FloatingActionButton fabAgregarTelefono;
    private FloatingActionButton fabAgregarEmail;
    private EditText txtNombre1;
    private RecyclerView rcvTelefonos3;
    private RecyclerView rcvEmails3;
    private AdaptadorTelefono adaptadorTelefono;
    private AdaptadorEmail adaptadorEmail;
    private Bundle bundle;
    private BDManager manager;
    public Contacto c;
    private ArrayList<Telefono> listaTelefonos;
    private ArrayList<String> listaEmails;
    private ImageView imgVista;
    private Telefono tf;
    private String numero;
    private String tipo;
    private String email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_contacto);
        manager = new BDManager(this);

        listaEmails=new ArrayList<>();
        listaTelefonos=new ArrayList<>();

        bundle = getIntent().getExtras();

        c = new Contacto(bundle.getString("nombre"), bundle.<Telefono>getParcelableArrayList("telefonos"), bundle.getStringArrayList("emails"), bundle.getString("foto"), bundle.getInt("id"));

        txtNombre1 = findViewById(R.id.txtNombre1);
        imgVista=findViewById(R.id.imgv1);
        fab1 = findViewById(R.id.fab1);
        fab2 = findViewById(R.id.fab2);
        fabAgregarTelefono=findViewById(R.id.btnAddTelefono1);
        fabAgregarEmail=findViewById(R.id.btnAddEmail1);
        rcvTelefonos3 = findViewById(R.id.rcvTelefonos3);
        rcvEmails3 = findViewById(R.id.rcvEmails3);

        txtNombre1.setText(c.getNombre());

        String image_uri = c.getFoto();

        if(c.getFoto().equals("girl")){
            imgVista.setImageResource(R.mipmap.girl);
        }else if(c.getFoto().equals("boy")){
            imgVista.setImageResource(R.mipmap.boy);
        }else if(c.getFoto().equals("dog")) {
            imgVista.setImageResource(R.mipmap.dog);
        }else if(c.getFoto().equals("zima")){
                imgVista.setImageResource(R.mipmap.zima);
        }else{
            imgVista.setImageURI(Uri.parse(image_uri));
        }

        listaTelefonos=c.getAlTelefono();
        listaEmails=c.getAlEmail();

        rcvEmails3.setLayoutManager(new LinearLayoutManager(this));
        adaptadorEmail = new AdaptadorEmail(listaEmails);
        rcvEmails3.setAdapter(adaptadorEmail);

        rcvTelefonos3.setLayoutManager(new LinearLayoutManager(this));
        adaptadorTelefono = new AdaptadorTelefono(listaTelefonos);
        rcvTelefonos3.setAdapter(adaptadorTelefono);


        fabAgregarTelefono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Simplemente cambiamos de actividad
                Intent intent = new Intent(EditarContactoActivity.this, AgregarTelefonoActivity.class);
                startActivityForResult(intent, 2);
            }
        });

        fabAgregarEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Simplemente cambiamos de actividad
                Intent intent = new Intent(EditarContactoActivity.this, AgregarEmailActivity.class);
                startActivityForResult(intent, 3);
            }
        });

        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre=txtNombre1.getText().toString();
                c.setNombre(nombre);
                String foto="";
                if (imgVista.getTag()!=null){
                    foto = imgVista.getTag().toString();
                }
                c.setFoto(foto);
                c.setAlTelefono(listaTelefonos);
                c.setAlEmail(listaEmails);
                manager.actualizarNombreYFoto(c.getNombre(),c.getFoto(),c.getId());
                finish();
            }
        });

        rcvEmails3.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rcvEmails3, new RecyclerTouchListener.ClickListener() {
            @Override // Un toque sencillo
            public void onClick(View view, final int position) {

                final String emailSeleccionado = listaEmails.get(position);
                AlertDialog dialog = new AlertDialog
                        .Builder(EditarContactoActivity.this)
                        .setPositiveButton("Borrar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                manager.borrarEmail(emailSeleccionado);
                                clearEmails();
                                consultarListasEmails();
                            }
                        })
                        .setNegativeButton("Mandar Email", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                mandarEmail(emailSeleccionado);
                            }
                        })
                        .create();
                dialog.show();
            }

            @Override
            public void onLongClick(View view, int position) {

            }

        }));


        rcvTelefonos3.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rcvTelefonos3, new RecyclerTouchListener.ClickListener() {
            @Override // Un toque sencillo
            public void onClick(View view, int position) {

                final Telefono telefonoSeleccionado = listaTelefonos.get(position);

                AlertDialog dialog = new AlertDialog
                        .Builder(EditarContactoActivity.this)
                        .setPositiveButton("Borrar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                manager.borrarTelefono(telefonoSeleccionado.getNumero());
                                clearTelefonos();
                                consultarListasTelefonos();
                            }
                        })
                        .setNegativeButton("Llamar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                                callIntent.setData(Uri.parse("tel:" + telefonoSeleccionado.getNumero()));
                                startActivity(callIntent);
                            }
                        })
                        .create();
                dialog.show();
            }

            @Override // Un toque largo
            public void onLongClick(View view, int position) {

            }
        }));
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        //galeria
        if (requestCode == REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                setImage(imgVista, data.getDataString());
            } else {
                Toast.makeText(this, R.string.permission_gallery_problem, Toast.LENGTH_LONG).show();
            }
        }

        //telefono
        super.onActivityResult(requestCode, resultCode, data);
        // Check which request we're responding to
        if (requestCode == 2) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {

                numero=data.getStringExtra("numero");
                tipo=data.getStringExtra("tipo");
                tf=new Telefono(numero, tipo, c.getId());
                manager.insertarTelefonoId(tf);
                listaTelefonos.add(tf);
                c.setAlTelefono(listaTelefonos);
            }
        }

        //emails
        super.onActivityResult(requestCode, resultCode, data);
        // Check which request we're responding to
        if (requestCode == 3) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {

                email=data.getStringExtra("email");
                manager.insertarEmailId(c.getId(),email);
                listaEmails.add(email);
                c.setAlEmail(listaEmails);
            }
        }
    }

    public void gallery(View view) {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(Intent.ACTION_PICK,
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, REQUEST_CODE);
        }
        else {
            requestPermission(Manifest.permission.READ_EXTERNAL_STORAGE, getResources().getString(R.string.permission_gallery_request),
                    REQUEST_CODE, this);
        }
    }

    public static void requestPermission(final String permission, String
            justification, final int requestCode, final Activity activity) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity,
                permission)){
            new android.support.v7.app.AlertDialog.Builder(activity)
                    .setTitle(R.string.request_permission)
                    .setMessage(justification)
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            ActivityCompat.requestPermissions(activity,
                                    new String[]{permission}, requestCode);
                        }})
                    .show();
        } else {
            ActivityCompat.requestPermissions(activity,
                    new String[]{permission}, requestCode);
        }
    }

    protected void setImage(ImageView imageView, String uri) {
        if (uri != null && !uri.isEmpty() && !uri.equals("null")) {
            imageView.setImageURI(Uri.parse(uri));
            imageView.setTag(getRealPathFromURI(Uri.parse(uri)));
        } else {
            imageView.setImageBitmap(null);
            imageView.setTag("");
        }
    }

    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(contentUri, proj, null, null, null);
        if (cursor == null) {
            return contentUri.getPath();
        }
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public void mandarEmail(String email){
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto",email, null));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Enviado Desde Zima Blue Agenda");
        startActivity(Intent.createChooser(emailIntent,  email));
    }

    public void clearTelefonos() {
        listaTelefonos.clear();
        adaptadorTelefono.notifyDataSetChanged();
    }
    public void clearEmails() {
        listaEmails.clear();
        adaptadorEmail.notifyDataSetChanged();
    }

    private void consultarListasTelefonos() {
        Cursor cursorTelefono=manager.getTelefono(c.getId());
        while (cursorTelefono.moveToNext()){
            String numero = cursorTelefono.getString(0);
            String tipo = cursorTelefono.getString(1);
            int id = cursorTelefono.getInt(2);
            Telefono telefono = new Telefono(numero, tipo, id);
            listaTelefonos.add(telefono);
        }
    }

    private void consultarListasEmails(){
        Cursor cursorEmail=manager.getEmail(c.getId());
        while (cursorEmail.moveToNext()){
            String email= cursorEmail.getString(0);
            listaEmails.add(email);
        }
    }

}
