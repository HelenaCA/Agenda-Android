package me.parzibyte.crudsqlite.actividades;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import me.parzibyte.crudsqlite.R;
import me.parzibyte.crudsqlite.database.BDManager;
import me.parzibyte.crudsqlite.modelos.Telefono;

public class AgregarTelefonoActivity extends AppCompatActivity {

    private Button btnCancelar;
    private Button btnAddTlf;
    private RadioButton rbFijo;
    private RadioButton rbMovil;
    private EditText numero;
    private RadioGroup rbGroupTelefonos;
    private BDManager manager;
    private Telefono t;
    private Intent resultIntent;
    private String numeroS;
    private String tipo;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.introducir_telefono);
        manager = new BDManager(this);

        btnCancelar=findViewById(R.id.btnCancelar);
        btnAddTlf=findViewById(R.id.btnAddTfn);
        rbFijo=findViewById(R.id.rbFijo);
        rbMovil=findViewById(R.id.rbMovil);
        numero=findViewById(R.id.etEmail);
        rbGroupTelefonos=findViewById(R.id.rbGrupoTelefonos);

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnAddTlf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                crearTelefono();
            }
        });

    }

    public void crearTelefono(){
        if(rbFijo.isChecked()){
            if (!checkEmpty(numero)) {
                resultIntent = new Intent();
                numeroS = numero.getText().toString();
                tipo = "Fijo";
                resultIntent.putExtra("numero", numeroS);
                resultIntent.putExtra("tipo", tipo);
                setResult(RESULT_OK, resultIntent);
                numero.setText("");
                t = new Telefono(numeroS, tipo);
                rbGroupTelefonos.clearCheck();
                finish();
            }

        }else if(rbMovil.isChecked()){
            if (!checkEmpty(numero)) {
                resultIntent = new Intent();
                numeroS = numero.getText().toString();
                tipo = "Móvil";
                resultIntent.putExtra("numero", numeroS);
                resultIntent.putExtra("tipo", tipo);
                setResult(RESULT_OK, resultIntent);
                numero.setText("");
                t = new Telefono(numeroS, tipo);
                rbGroupTelefonos.clearCheck();
                finish();
            }
        }
    }

    public boolean checkEmpty(EditText input){
        if(TextUtils.isEmpty(input.getText().toString())){
            input.setError("Este campo no puede estar vacío");
            input.requestFocus();
            return true;
        }
        return false;
    }
}
