package me.parzibyte.crudsqlite.adaptadores;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import me.parzibyte.crudsqlite.R;
import me.parzibyte.crudsqlite.modelos.Telefono;

public class AdaptadorTelefono extends RecyclerView.Adapter<AdaptadorTelefono.ViewHolderTelefonos> {
    ArrayList<Telefono> listaTelefonos;

    public AdaptadorTelefono(ArrayList<Telefono> listaTelefonos) {
        this.listaTelefonos = listaTelefonos;
    }

    public void setTelefonoA(ArrayList<Telefono> listaDeTelefonos) {
        this.listaTelefonos = listaDeTelefonos;
    }

    @Override
    public AdaptadorTelefono.ViewHolderTelefonos onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.telefono_view_item,null,false);
        return new ViewHolderTelefonos(view);
    }

    @Override
    public void onBindViewHolder(AdaptadorTelefono.ViewHolderTelefonos holder, int position) {
        holder.telefonoVista.setText(listaTelefonos.get(position).getNumero());
        holder.tipoVista.setText(listaTelefonos.get(position).getTipo());
    }

    @Override
    public int getItemCount() {
        return listaTelefonos.size();
    }

    public class ViewHolderTelefonos extends RecyclerView.ViewHolder {
        TextView telefonoVista;
        TextView tipoVista;
        public ViewHolderTelefonos(View itemView) {
            super(itemView);
            tipoVista=(TextView)itemView.findViewById(R.id.txtTipoItem);
            telefonoVista=(TextView)itemView.findViewById(R.id.txtTelefonoItem);
        }


    }
}
