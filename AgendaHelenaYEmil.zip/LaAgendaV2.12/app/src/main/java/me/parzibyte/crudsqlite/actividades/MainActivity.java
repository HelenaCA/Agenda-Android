package me.parzibyte.crudsqlite.actividades;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;

import me.parzibyte.crudsqlite.R;
import me.parzibyte.crudsqlite.adaptadores.AdaptadorContacto;
import me.parzibyte.crudsqlite.adaptadores.RecyclerTouchListener;
import me.parzibyte.crudsqlite.database.BDManager;
import me.parzibyte.crudsqlite.modelos.Contacto;
import me.parzibyte.crudsqlite.modelos.Telefono;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Contacto> listaContactos;
    private RecyclerView recyclerView;
    private AdaptadorContacto adaptadorContacto;
    private FloatingActionButton fabAgregarContacto;
    private BDManager manager;
    private int posLlamar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        manager=new BDManager(this);
        listaContactos = new ArrayList<>();

        recyclerView = findViewById(R.id.recyclerViewContactos);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        fabAgregarContacto = findViewById(R.id.fabAgregarContacto);

        posLlamar=0;

        adaptadorContacto = new AdaptadorContacto(listaContactos);
        recyclerView.setAdapter(adaptadorContacto);

        clear();
        refrescarListaDeContactos();

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override // Un click corto
            public void onLongClick(View view, int position) {
                // Pasar a la actividad EditarContactoActivity.java
                final Contacto contactoSeleccionado = (Contacto)listaContactos.get(position);

                posLlamar=position;

                AlertDialog dialog = new AlertDialog
                        .Builder(MainActivity.this)
                        .setPositiveButton("Editar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(MainActivity.this, EditarContactoActivity.class);
                                intent.putExtra("id", contactoSeleccionado.getId());
                                intent.putExtra("nombre", contactoSeleccionado.getNombre());
                                intent.putStringArrayListExtra("emails", contactoSeleccionado.getAlEmail());
                                intent.putExtra("foto", contactoSeleccionado.getFoto());
                                intent.putParcelableArrayListExtra("telefonos", contactoSeleccionado.getAlTelefono());
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("Eliminar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                manager.eliminarContacto(contactoSeleccionado);
                                clear();
                                refrescarListaDeContactos();
                            }
                        })
                        .setTitle("Confirmar")
                        .setMessage("Elija una opcion para el contacto : " + contactoSeleccionado.getNombre())
                        .create();
                dialog.show();
            }

            @Override // Un click largo
            public void onClick(View view, int position) {
                posLlamar = position;

            }
        }));

        // Listener del FAB
        fabAgregarContacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Simplemente cambiamos de actividad
                Intent intent = new Intent(MainActivity.this, AgregarContactoActivity.class);
                startActivity(intent);
            }
        });

        // Créditos
        fabAgregarContacto.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Acerca de")
                        .setMessage("Una Agenda hecha por Emil y Helena")
                        .setNegativeButton("Cerrar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogo, int which) {
                                dialogo.dismiss();
                            }
                        })
                        .setPositiveButton("Sitio web", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intentNavegador = new Intent(Intent.ACTION_VIEW, Uri.parse("https://elmundotoday.com"));
                                startActivity(intentNavegador);
                            }
                        })
                        .create()
                        .show();
                return false;
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        clear();
        refrescarListaDeContactos();
    }

    public void refrescarListaDeContactos() {
        if (adaptadorContacto == null) return;
        listaContactos = manager.obtenerContacto();
        adaptadorContacto.setListaContactos(listaContactos);
        adaptadorContacto.notifyDataSetChanged();
        clear();
        consultarListaPersonas();
    }

    private void consultarListaPersonas() {

        manager=new BDManager(this);

        Contacto c=null;
        Cursor cursor=manager.cargarContactosCursor();

        while (cursor.moveToNext()){
            String nombre = cursor.getString(1);
            String foto = cursor.getString(2);
            ArrayList<Telefono> listaTelefonos = new ArrayList<>();
            ArrayList<String> listaEmails = new ArrayList<>();

            Cursor cursorTelefono=manager.getTelefono(cursor.getInt(0));
            while (cursorTelefono.moveToNext()){
                String numero = cursorTelefono.getString(0);
                String tipo = cursorTelefono.getString(1);
                int id = cursorTelefono.getInt(2);
                Telefono telefono = new Telefono(numero, tipo, id);
                listaTelefonos.add(telefono);
            }

            Cursor cursorEmail=manager.getEmail(cursor.getInt(0));
            while (cursorEmail.moveToNext()){
                String email= cursorEmail.getString(0);

                listaEmails.add(email);
            }

            c=new Contacto(nombre, listaTelefonos,listaEmails, foto);
            c.setId(cursor.getInt(0));
            listaContactos.add(c);
        }
    }

    public void clear() {
        listaContactos.clear();
        adaptadorContacto.notifyDataSetChanged();
    }

    public void llamar(View view){
        Contacto contactoSeleccionado = (Contacto)listaContactos.get(posLlamar);
        Intent callIntent = new Intent(Intent.ACTION_DIAL);
        callIntent.setData(Uri.parse("tel:"+contactoSeleccionado.getPrimerNumero()));
        startActivity(callIntent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
