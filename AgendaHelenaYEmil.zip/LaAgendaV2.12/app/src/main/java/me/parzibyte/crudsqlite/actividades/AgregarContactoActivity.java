package me.parzibyte.crudsqlite.actividades;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

import me.parzibyte.crudsqlite.R;
import me.parzibyte.crudsqlite.adaptadores.AdaptadorEmail;
import me.parzibyte.crudsqlite.adaptadores.AdaptadorTelefono;
import me.parzibyte.crudsqlite.adaptadores.RecyclerTouchListener;
import me.parzibyte.crudsqlite.database.BDManager;
import me.parzibyte.crudsqlite.modelos.Contacto;
import me.parzibyte.crudsqlite.modelos.Telefono;

public class AgregarContactoActivity extends AppCompatActivity {


    final static int REQUEST_CODE = 1;

    private FloatingActionButton btnAgregarContacto;
    private FloatingActionButton btnCancelarNuevoContacto;
    private FloatingActionButton btnAgregarTelefono;
    private FloatingActionButton btnAgregarEmail;
    private EditText txtNombre1;
    private ImageView imgVista;
    public RecyclerView rcvTelefonos1;
    public RecyclerView rcvEmails1;
    private AdaptadorTelefono adaptadorTelefono;
    private AdaptadorEmail adaptadorEmail;
    private BDManager manager;
    public Contacto c;
    private Telefono tf;
    private ArrayList<Telefono> listaTelefonos;
    private ArrayList<String> listaEmails;
    private String numero;
    private String tipo;
    private String email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_contacto);

        manager=new BDManager(this);
        c=new Contacto();
        listaTelefonos=new ArrayList<>();
        listaEmails=new ArrayList<>();

        txtNombre1 = findViewById(R.id.txtNombre1);
        imgVista=findViewById(R.id.imageView2);
        btnAgregarContacto = findViewById(R.id.fab1);
        btnCancelarNuevoContacto = findViewById(R.id.fab2);
        btnAgregarTelefono=findViewById(R.id.btnAddTelefono1);
        btnAgregarEmail=findViewById(R.id.btnAddEmail1);

        rcvTelefonos1=findViewById(R.id.rcvTelefonos1);
        rcvTelefonos1.setLayoutManager(new LinearLayoutManager(this));

        rcvEmails1=findViewById(R.id.rcvEmails1);
        rcvEmails1.setLayoutManager(new LinearLayoutManager(this));

        adaptadorEmail = new AdaptadorEmail(listaEmails);
        rcvEmails1.setAdapter(adaptadorEmail);

        adaptadorTelefono = new AdaptadorTelefono(listaTelefonos);
        rcvTelefonos1.setAdapter(adaptadorTelefono);

        refrescarListaDeTelefonos();
        refrescarListaDeEmails();

        // Cerramos actividad
        btnCancelarNuevoContacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnAgregarTelefono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Cambiamos de actividad
                Intent intent = new Intent(AgregarContactoActivity.this, AgregarTelefonoActivity.class);
                startActivityForResult(intent, 2);
            }
        });

        btnAgregarEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Cambiamos de actividad
                Intent intent = new Intent(AgregarContactoActivity.this, AgregarEmailActivity.class);
                startActivityForResult(intent,3);
            }
        });

        rcvTelefonos1.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rcvTelefonos1, new RecyclerTouchListener.ClickListener() {
            @Override // Un click corto
            public void onClick(View view, final int position) {

                final Telefono telefonoSeleccionado = listaTelefonos.get(position);

                android.app.AlertDialog dialog = new android.app.AlertDialog
                        .Builder(AgregarContactoActivity.this)
                        .setPositiveButton("Borrar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                manager.borrarTelefono(telefonoSeleccionado.getNumero());
                                listaTelefonos.remove(telefonoSeleccionado);
                                adaptadorTelefono.setTelefonoA(listaTelefonos);
                                adaptadorTelefono.notifyDataSetChanged();
                            }
                        })
                        .create();
                dialog.show();
            }

            @Override
            public void onLongClick(View view, int position) {

            }

        }));

        rcvEmails1.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rcvEmails1, new RecyclerTouchListener.ClickListener() {
            @Override // Un click corto
            public void onClick(View view, final int position) {

                final String emailSeleccionado = listaEmails.get(position);
                android.app.AlertDialog dialog = new android.app.AlertDialog
                        .Builder(AgregarContactoActivity.this)
                        .setPositiveButton("Borrar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                manager.borrarEmail(emailSeleccionado);
                                listaEmails.remove(emailSeleccionado);
                                adaptadorEmail.setEmailA(listaEmails);
                                adaptadorEmail.notifyDataSetChanged();
                            }
                        })
                        .create();
                dialog.show();
            }

            @Override
            public void onLongClick(View view, int position) {

            }

        }));

        // Agregar listener del botón de guardar
        btnAgregarContacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!checkEmpty(txtNombre1)) {

                    String foto = "";

                    if (imgVista.getTag() != null) {
                        foto = imgVista.getTag().toString();
                    }

                    checkEmpty(txtNombre1);

                    String nombre = txtNombre1.getText().toString();
                    c.setNombre(nombre);
                    c.setFoto(foto);
                    c.setAlTelefono(listaTelefonos);
                    c.setAlEmail(listaEmails);
                    manager.crearContacto(c);
                    finish();
                }

            }
        });
    }

    public void gallery(View view) {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(Intent.ACTION_PICK,
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, REQUEST_CODE);
        }
        else {
            requestPermission(Manifest.permission.READ_EXTERNAL_STORAGE, getResources().getString(R.string.permission_gallery_request),
                    REQUEST_CODE, this);
        }
    }

    public static void requestPermission(final String permission, String
            justification, final int requestCode, final Activity activity) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity,
                permission)){
            new AlertDialog.Builder(activity)
                    .setTitle(R.string.request_permission)
                    .setMessage(justification)
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            ActivityCompat.requestPermissions(activity,
                                    new String[]{permission}, requestCode);
                        }})
                    .show();
        } else {
            ActivityCompat.requestPermissions(activity,
                    new String[]{permission}, requestCode);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        //galeria
        if (requestCode == REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                setImage(imgVista, data.getDataString());
            } else {
                Toast.makeText(this, R.string.permission_gallery_problem, Toast.LENGTH_LONG).show();
            }
        }

        //telefono
        super.onActivityResult(requestCode, resultCode, data);
        // Check which request we're responding to
        if (requestCode == 2) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {

                numero=data.getStringExtra("numero");
                tipo=data.getStringExtra("tipo");
                tf=new Telefono(numero, tipo);
                manager.insertarTelefono(tf);
                listaTelefonos.add(tf);
                c.setAlTelefono(listaTelefonos);
            }
        }

        //emails
        super.onActivityResult(requestCode, resultCode, data);
        // Check which request we're responding to
        if (requestCode == 3) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {

                email=data.getStringExtra("email");
                listaEmails.add(email);
                c.setAlEmail(listaEmails);
                manager.insertarEmail(email);
            }
        }
    }

    protected void setImage(ImageView imageView, String uri) {
        if (uri != null && !uri.isEmpty() && !uri.equals("null")) {
            imageView.setImageURI(Uri.parse(uri));
            imageView.setTag(getRealPathFromURI(Uri.parse(uri)));
        } else {
            imageView.setImageBitmap(null);
            imageView.setTag("");
        }
    }

    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(contentUri, proj, null, null, null);
        if (cursor == null) {
            return contentUri.getPath();
        }
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public boolean checkEmpty(EditText input){
        if(TextUtils.isEmpty(input.getText().toString())){
            input.setError("Este campo no puede estar vacío");
            input.requestFocus();
            return true;
        }
        return false;
    }

    public void refrescarListaDeTelefonos() {

        if (adaptadorTelefono == null) return;
        adaptadorTelefono.setTelefonoA(listaTelefonos);
        adaptadorTelefono.notifyDataSetChanged();
    }

    public void refrescarListaDeEmails() {

        if (adaptadorEmail == null) return;
        adaptadorEmail.setEmailA(listaEmails);
        adaptadorEmail.notifyDataSetChanged();
    }

}
